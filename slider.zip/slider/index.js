


function slide(){
    let n=parseInt(document.getElementById("num").value);
let p=n+n;
let q=p+n;
setInterval(pic1,n);
setInterval(pic2,p)
setInterval(pic3,q)
function pic1(){
    document.getElementById("slider").src="images.jpg";
    
}


function pic2(){
    document.getElementById("slider").src="images (2).jpg";
}

function pic3(){
    document.getElementById("slider").src="images (1).jpg";
}


}
document.getElementById("btn").addEventListener("click",slide)


